ssh root@192.168.56.31 "poweroff"
ssh root@192.168.56.32 "poweroff"
